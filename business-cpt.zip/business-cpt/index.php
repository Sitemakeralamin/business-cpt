<?php
/*
Plugin Name:Business Custom Post
Plugin URI: https://akismet.com/
Description: Used by millions, Akismet is quite possibly the best way in the world to <strong>protect your blog from spam</strong>. It keeps your site protected even while you sleep. To get started: activate the Akismet plugin and then go to your Akismet Settings page to set up your API key.
Version: 4.1.9
Author:alamin
Author URI: https://alamin.com/wordpress-plugins/

Text Domain:business
*/

// 
// Custom Post Register Testomonial
//

function custom_post(){
register_post_type('testomonial',array(

	'labels' => array(
	
		'name'=>__('testomonials','business'),
		'singular_name'=>__('testomonial','business'),
		'add_new'=>__('add testomonial','business'),
		'add_new_item'=>__('add new testomonial','business'),
		'edit_item'=>__('edit testomonial','business'),
		 'view_item'=>__('view testomonial','business'),
		 'search_items'=>__('search testomonial','business'),
	
	),
	
	'public'=> true,
	



));
	
	
// 
// Custom Post Register Our Team
//	

	register_post_type('team',array(

	'labels' => array(
	
		'name'=>__('Our Team','business'),
		'singular_name'=>__('Ourtems','business'),
		'add_new'=>__('add Team members','business'),
		'add_new_item'=>__('add new Member','business'),
		'edit_item'=>__('edit Team member','business'),
		 'view_item'=>__('view Team','business'),
		 'search_items'=>__('search Team','business'),
	
	),
	
	'public'=> true,
	 'supports' => array( 'title', 'editor', 'thumbnail','page-attributes' ),
		



));
	
	
}
add_action('init','custom_post');


